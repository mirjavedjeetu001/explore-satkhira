@extends('frontend.layouts.app')

@section('title', 'আমাদের সম্পর্কে')

@section('content')
    <!-- Breadcrumb -->
    <section class="breadcrumb-section">
        <div class="container">
            <h1>আমাদের সম্পর্কে</h1>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="{{ route('home') }}">হোম</a></li>
                    <li class="breadcrumb-item active">আমাদের সম্পর্কে</li>
                </ol>
            </nav>
        </div>
    </section>

    <!-- About Intro -->
    <section class="py-5">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6" data-aos="fade-right">
                    <img src="https://picsum.photos/seed/satkhira/600/400" class="img-fluid rounded shadow" alt="সাতক্ষীরা">
                </div>
                <div class="col-lg-6" data-aos="fade-left">
                    <h2 class="mb-4">সাতক্ষীরা পোর্টাল সম্পর্কে</h2>
                    <p class="lead">
                        {{ $settings['about_intro'] ?? 'সাতক্ষীরা পোর্টাল হলো সাতক্ষীরা জেলার সকল তথ্যের একটি সমন্বিত ডিজিটাল প্ল্যাটফর্ম।' }}
                    </p>
                    <p class="text-muted">
                        {{ $settings['about_description'] ?? 'এই পোর্টালের মাধ্যমে আপনি সাতক্ষীরা জেলার ৭টি উপজেলার সকল গুরুত্বপূর্ণ তথ্য, হাসপাতাল, শিক্ষা প্রতিষ্ঠান, সরকারি অফিস, ব্যবসা প্রতিষ্ঠান এবং অন্যান্য সেবা সম্পর্কে জানতে পারবেন।' }}
                    </p>
                    <div class="row mt-4">
                        <div class="col-6">
                            <div class="d-flex align-items-center mb-3">
                                <div class="bg-success text-white rounded-circle p-3 me-3">
                                    <i class="fas fa-map-marker-alt"></i>
                                </div>
                                <div>
                                    <h5 class="mb-0">৭</h5>
                                    <small class="text-muted">উপজেলা</small>
                                </div>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="d-flex align-items-center mb-3">
                                <div class="bg-success text-white rounded-circle p-3 me-3">
                                    <i class="fas fa-users"></i>
                                </div>
                                <div>
                                    <h5 class="mb-0">২০ লক্ষ+</h5>
                                    <small class="text-muted">জনসংখ্যা</small>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Mission & Vision -->
    <section class="py-5 bg-light">
        <div class="container">
            <div class="row g-4">
                <div class="col-md-6" data-aos="fade-up">
                    <div class="card h-100 border-0 shadow-sm">
                        <div class="card-body p-4">
                            <div class="d-flex align-items-center mb-4">
                                <div class="bg-success text-white rounded p-3 me-3">
                                    <i class="fas fa-bullseye fa-2x"></i>
                                </div>
                                <h3 class="mb-0">আমাদের লক্ষ্য</h3>
                            </div>
                            <p>{{ $settings['mission'] ?? 'সাতক্ষীরা জেলার সকল নাগরিকদের জন্য একটি সহজ ও সুলভ তথ্য সেবা প্রদান করা। স্থানীয় ব্যবসা, সেবা ও প্রতিষ্ঠানগুলোকে ডিজিটাল প্ল্যাটফর্মে নিয়ে আসা এবং জনগণ ও সংসদ সদস্যের মধ্যে সেতুবন্ধন তৈরি করা।' }}</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-6" data-aos="fade-up" data-aos-delay="100">
                    <div class="card h-100 border-0 shadow-sm">
                        <div class="card-body p-4">
                            <div class="d-flex align-items-center mb-4">
                                <div class="bg-success text-white rounded p-3 me-3">
                                    <i class="fas fa-eye fa-2x"></i>
                                </div>
                                <h3 class="mb-0">আমাদের দৃষ্টিভঙ্গি</h3>
                            </div>
                            <p>{{ $settings['vision'] ?? 'সাতক্ষীরা জেলাকে ডিজিটাল দিক থেকে দেশের একটি অগ্রণী জেলা হিসেবে গড়ে তোলা। প্রতিটি নাগরিকের হাতের মুঠোয় প্রয়োজনীয় তথ্য পৌঁছে দেওয়া এবং স্বচ্ছ ও জবাবদিহিমূলক সেবা নিশ্চিত করা।' }}</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Features -->
    <section class="py-5">
        <div class="container">
            <div class="text-center mb-5" data-aos="fade-up">
                <h2>আমাদের সেবাসমূহ</h2>
                <div class="underline mx-auto" style="width: 80px; height: 4px; background: linear-gradient(90deg, #1a5f2a, #28a745); border-radius: 2px;"></div>
            </div>
            
            <div class="row g-4">
                <div class="col-md-4" data-aos="fade-up">
                    <div class="card h-100 border-0 shadow-sm text-center p-4">
                        <div class="bg-success text-white rounded-circle mx-auto mb-3" style="width: 80px; height: 80px; display: flex; align-items: center; justify-content: center;">
                            <i class="fas fa-database fa-2x"></i>
                        </div>
                        <h5>তথ্য ভান্ডার</h5>
                        <p class="text-muted">হাসপাতাল, শিক্ষা প্রতিষ্ঠান, সরকারি অফিস, ব্যবসা প্রতিষ্ঠান সহ সকল গুরুত্বপূর্ণ তথ্য এক জায়গায়</p>
                    </div>
                </div>
                <div class="col-md-4" data-aos="fade-up" data-aos-delay="100">
                    <div class="card h-100 border-0 shadow-sm text-center p-4">
                        <div class="bg-success text-white rounded-circle mx-auto mb-3" style="width: 80px; height: 80px; display: flex; align-items: center; justify-content: center;">
                            <i class="fas fa-comments fa-2x"></i>
                        </div>
                        <h5>MP প্রশ্নোত্তর</h5>
                        <p class="text-muted">মাননীয় সংসদ সদস্যকে সরাসরি প্রশ্ন করুন এবং উত্তর পান</p>
                    </div>
                </div>
                <div class="col-md-4" data-aos="fade-up" data-aos-delay="200">
                    <div class="card h-100 border-0 shadow-sm text-center p-4">
                        <div class="bg-success text-white rounded-circle mx-auto mb-3" style="width: 80px; height: 80px; display: flex; align-items: center; justify-content: center;">
                            <i class="fas fa-user-plus fa-2x"></i>
                        </div>
                        <h5>তথ্য যোগ করুন</h5>
                        <p class="text-muted">নিবন্ধন করে আপনার এলাকার তথ্য যোগ করুন এবং সমাজে অবদান রাখুন</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Contact CTA -->
    <section class="py-5 bg-success text-white">
        <div class="container text-center" data-aos="fade-up">
            <h2 class="mb-3">আপনার মতামত জানান</h2>
            <p class="lead mb-4">পোর্টাল সম্পর্কে কোন প্রশ্ন বা পরামর্শ থাকলে আমাদের জানান</p>
            <a href="{{ route('contact') }}" class="btn btn-warning btn-lg">
                <i class="fas fa-envelope me-2"></i>যোগাযোগ করুন
            </a>
        </div>
    </section>
@endsection
