<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Listing;
use App\Models\ListingImage;
use App\Models\MpProfile;
use App\Models\News;
use App\Models\Slider;
use App\Models\Upazila;
use App\Models\FuelReport;
use App\Models\FuelSetting;
use App\Models\FuelStation;

class HomeController extends Controller
{
    public function index()
    {
        $sliders = Slider::active()->ordered()->get();
        
        $categories = Category::active()
            ->parentCategories()
            ->inMenu()
            ->ordered()
            ->withCount(['listings' => fn($q) => $q->approved()])
            ->get()
            ->sortByDesc('listings_count')
            ->values();

        $upazilas = Upazila::active()
            ->ordered()
            ->withCount(['listings' => fn($q) => $q->approved()])
            ->get();

        $featuredListings = Listing::approved()
            ->notExpired()
            ->featured()
            ->with(['category', 'upazila'])
            ->latest()
            ->take(8)
            ->get();

        $latestListings = Listing::approved()
            ->notExpired()
            ->with(['category', 'upazila'])
            ->latest()
            ->take(6)
            ->get();

        $latestNews = News::active()
            ->news()
            ->latest()
            ->take(4)
            ->get();

        $mpProfiles = MpProfile::active()->orderBy('constituency')->take(4)->get();

        // Homepage promotional ads
        $homepageAds = ListingImage::homepage()
            ->with('listing')
            ->take(6)
            ->get();

        // Fuel availability reports - same logic as fuel page for full sync
        $fuelEnabled = FuelSetting::isEnabled();
        $fuelReports = collect();
        if ($fuelEnabled) {
            // Get all active stations with upazila
            $fuelStations = FuelStation::with('upazila')->where('is_active', true)->get();
            
            // Attach latest valid report for each station
            $fuelStations->each(function($station) {
                $station->displayReport = FuelReport::where('fuel_station_id', $station->id)
                    ->where('is_verified', true)
                    ->orderByDesc('created_at')
                    ->first();
                
                if (!$station->displayReport) {
                    $station->displayReport = FuelReport::where('fuel_station_id', $station->id)
                        ->where(function($q) {
                            $q->where('incorrect_votes', '<', 10)
                              ->orWhereNull('incorrect_votes');
                        })
                        ->orderByDesc('created_at')
                        ->first();
                }
            });
            
            // Filter out stations without reports, then sort same as fuel page
            $fuelStations = $fuelStations->filter(fn($s) => $s->displayReport !== null);
            
            $fuelStations = $fuelStations->sortBy(function($station) {
                $report = $station->displayReport;
                $isVerified = $report->is_verified;
                $correctVotes = $report->correct_votes ?? 0;
                $incorrectVotes = $report->incorrect_votes ?? 0;
                
                if ($isVerified) $tier = 0;
                elseif ($incorrectVotes >= 10) $tier = 3;
                elseif ($correctVotes >= 10) $tier = 1;
                else $tier = 2;
                
                return [$tier, -$correctVotes, -$report->created_at->timestamp];
            })->take(6)->values();
            
            // Map to reports with fuelStation attached for view compatibility
            $fuelReports = $fuelStations->map(function($station) {
                $report = $station->displayReport;
                $report->setRelation('fuelStation', $station);
                return $report;
            });
        }

        return view('frontend.home', compact(
            'sliders',
            'categories',
            'upazilas',
            'featuredListings',
            'latestListings',
            'latestNews',
            'mpProfiles',
            'homepageAds',
            'fuelEnabled',
            'fuelReports'
        ));
    }
}
